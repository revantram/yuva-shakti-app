package com.yuvashaktigroup.app;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class mipmap {
        public static final int ic_launcher = 0x7f010000;
        public static final int ic_launcher_round = 0x7f010001;
    }

    public static final class string {
        public static final int app_name = 0x7f020000;
    }
}
