###### Class com.yuvashaktigroup.app.MainActivity (com.yuvashaktigroup.app.MainActivity)
.class public Lcom/yuvashaktigroup/app/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;
    }
.end annotation


# static fields
.field private static final FILECHOOSER_RESULTCODE:I = 0x3e9


# instance fields
.field private mFilePathCallback:Landroid/webkit/ValueCallback;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/webkit/ValueCallback<",
            "[",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation
.end field

.field private mLastBackPressTime:J

.field private mWebView:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 48
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 51
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mLastBackPressTime:J

    return-void
.end method

.method static synthetic access$000(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 48
    invoke-direct {p0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->showSystemNotification(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$100(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 1

    .line 48
    invoke-direct {p0}, Lcom/yuvashaktigroup/app/MainActivity;->checkAndRequestNotificationPermission()V

    return-void
.end method

.method static synthetic access$200(Lcom/yuvashaktigroup/app/MainActivity;)Landroid/webkit/ValueCallback;
    .registers 1

    .line 48
    iget-object p0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mFilePathCallback:Landroid/webkit/ValueCallback;

    return-object p0
.end method

.method static synthetic access$202(Lcom/yuvashaktigroup/app/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;
    .registers 2

    .line 48
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mFilePathCallback:Landroid/webkit/ValueCallback;

    return-object p1
.end method

.method static synthetic access$300(Lcom/yuvashaktigroup/app/MainActivity;Ljava/io/File;Ljava/io/File;)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 48
    invoke-direct {p0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->copyFile(Ljava/io/File;Ljava/io/File;)V

    return-void
.end method

.method static synthetic access$400(Lcom/yuvashaktigroup/app/MainActivity;)Landroid/webkit/WebView;
    .registers 1

    .line 48
    iget-object p0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    return-object p0
.end method

.method static synthetic access$500(Lcom/yuvashaktigroup/app/MainActivity;Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V
    .registers 5

    .line 48
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/yuvashaktigroup/app/MainActivity;->drawTableHeader(Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V

    return-void
.end method

.method static synthetic access$600(Lcom/yuvashaktigroup/app/MainActivity;Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V
    .registers 5

    .line 48
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/yuvashaktigroup/app/MainActivity;->drawPageFooter(Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V

    return-void
.end method

.method private checkAndRequestNotificationPermission()V
    .registers 4

    .line 128
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_19

    .line 129
    const-string v0, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_19

    .line 130
    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    aput-object v0, v1, v2

    const/16 v0, 0xc8

    invoke-virtual {p0, v1, v0}, Lcom/yuvashaktigroup/app/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    .line 133
    :cond_19
    return-void
.end method

.method private copyFile(Ljava/io/File;Ljava/io/File;)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 903
    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 904
    :try_start_5
    new-instance p1, Ljava/io/FileOutputStream;

    invoke-direct {p1, p2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_a
    .catchall {:try_start_5 .. :try_end_a} :catchall_2a

    .line 905
    const/16 p2, 0x2000

    :try_start_c
    new-array p2, p2, [B

    .line 907
    :goto_e
    invoke-virtual {v0, p2}, Ljava/io/InputStream;->read([B)I

    move-result v1

    if-lez v1, :cond_19

    .line 908
    const/4 v2, 0x0

    invoke-virtual {p1, p2, v2, v1}, Ljava/io/OutputStream;->write([BII)V
    :try_end_18
    .catchall {:try_start_c .. :try_end_18} :catchall_20

    goto :goto_e

    .line 910
    :cond_19
    :try_start_19
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V
    :try_end_1c
    .catchall {:try_start_19 .. :try_end_1c} :catchall_2a

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 911
    return-void

    .line 903
    :catchall_20
    move-exception p2

    :try_start_21
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V
    :try_end_24
    .catchall {:try_start_21 .. :try_end_24} :catchall_25

    goto :goto_29

    :catchall_25
    move-exception p1

    :try_start_26
    invoke-static {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity$0;->m(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :goto_29
    throw p2
    :try_end_2a
    .catchall {:try_start_26 .. :try_end_2a} :catchall_2a

    :catchall_2a
    move-exception p1

    :try_start_2b
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_2f

    goto :goto_33

    :catchall_2f
    move-exception p2

    invoke-static {p1, p2}, Lcom/yuvashaktigroup/app/MainActivity$0;->m(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :goto_33
    goto :goto_35

    :goto_34
    throw p1

    :goto_35
    goto :goto_34
.end method

.method private drawPageFooter(Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V
    .registers 8

    .line 889
    const-string v0, "#94a3b8"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 890
    const/high16 v0, 0x41000000    # 8.0f

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 891
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 892
    if-eqz p4, :cond_1d

    .line 893
    const-string v0, "Yuva Shakti Group \u2022 Kuchera (Nagaur) \u2022 Parivar Management"

    goto :goto_1f

    .line 894
    :cond_1d
    const-string v0, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a \u2022 \u0915\u0941\u091a\u0947\u0930\u093e (\u0928\u093e\u0917\u094c\u0930) \u2022 \u092a\u0930\u093f\u0935\u093e\u0930 \u092a\u094d\u0930\u092c\u0902\u0927\u0928 \u090f\u0935\u0902 \u092c\u0939\u0940-\u0916\u093e\u0924\u093e"

    .line 895
    :goto_1f
    const/high16 v1, 0x42280000    # 42.0f

    const/high16 v2, 0x444d0000    # 820.0f

    invoke-virtual {p1, v0, v1, v2, p2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 897
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz p4, :cond_30

    const-string p4, "Page "

    goto :goto_32

    :cond_30
    const-string p4, "\u092a\u0943\u0937\u094d\u0920 "

    :goto_32
    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p4

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    .line 898
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p4

    .line 899
    const v0, 0x44098000    # 550.0f

    sub-float/2addr v0, p4

    invoke-virtual {p1, p3, v0, v2, p2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 900
    return-void
.end method

.method private drawTableHeader(Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V
    .registers 15

    .line 867
    const-string v0, "#f1f5f9"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 868
    add-int/lit8 v0, p3, -0xe

    int-to-float v3, v0

    add-int/lit8 v0, p3, 0x8

    int-to-float v5, v0

    const/high16 v2, 0x42100000    # 36.0f

    const v4, 0x440bc000    # 559.0f

    move-object v1, p1

    move-object v6, p2

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 870
    const-string p1, "#334155"

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 871
    const/high16 p1, 0x41100000    # 9.0f

    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 872
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 p2, 0x1

    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 874
    if-eqz p4, :cond_36

    const-string p1, "DESCRIPTION / MEMBER"

    goto :goto_38

    :cond_36
    const-string p1, "\u0935\u093f\u0935\u0930\u0923 / \u0938\u0926\u0938\u094d\u092f"

    :goto_38
    int-to-float p2, p3

    const/high16 p3, 0x42280000    # 42.0f

    invoke-virtual {v1, p1, p3, p2, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 875
    if-eqz p4, :cond_43

    const-string p1, "DATE"

    goto :goto_45

    :cond_43
    const-string p1, "\u0924\u093e\u0930\u0940\u0916"

    :goto_45
    const/high16 p3, 0x43750000    # 245.0f

    invoke-virtual {v1, p1, p3, p2, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 876
    if-eqz p4, :cond_4f

    const-string p1, "METHOD"

    goto :goto_51

    :cond_4f
    const-string p1, "\u092e\u093e\u0927\u094d\u092f\u092e"

    :goto_51
    const p3, 0x43a28000    # 325.0f

    invoke-virtual {v1, p1, p3, p2, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 877
    if-eqz p4, :cond_5c

    const-string p1, "TYPE"

    goto :goto_5e

    :cond_5c
    const-string p1, "\u092a\u094d\u0930\u0915\u093e\u0930"

    :goto_5e
    const/high16 p3, 0x43cd0000    # 410.0f

    invoke-virtual {v1, p1, p3, p2, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 879
    if-eqz p4, :cond_68

    const-string p1, "AMOUNT"

    goto :goto_6a

    :cond_68
    const-string p1, "\u0930\u093e\u0936\u093f"

    .line 880
    :goto_6a
    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p3

    .line 881
    const p4, 0x44098000    # 550.0f

    sub-float/2addr p4, p3

    invoke-virtual {v1, p1, p4, p2, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 883
    const-string p1, "#cbd5e1"

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 884
    const/high16 p1, 0x3f800000    # 1.0f

    invoke-virtual {v6, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 885
    move-object v9, v6

    move v6, v5

    const/high16 v5, 0x42100000    # 36.0f

    const v7, 0x440bc000    # 559.0f

    move v8, v6

    move-object v4, v1

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 886
    return-void
.end method

.method private showSystemNotification(Ljava/lang/String;Ljava/lang/String;)V
    .registers 11

    .line 915
    :try_start_0
    const-string v0, "notification"

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 916
    if-nez v0, :cond_b

    return-void

    .line 917
    :cond_b
    const-string v1, "yuva_shakti_alerts_channel"

    .line 918
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    const/4 v4, 0x1

    if-lt v2, v3, :cond_36

    .line 919
    new-instance v2, Landroid/app/NotificationChannel;

    const-string v5, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a \u0905\u0932\u0930\u094d\u091f \u090f\u0935\u0902 \u0938\u0942\u091a\u0928\u093e\u090f\u0902"

    const/4 v6, 0x4

    invoke-direct {v2, v1, v5, v6}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 924
    const-string v5, "\u0938\u0941\u0935\u093f\u091a\u093e\u0930, \u0905\u0902\u0936\u0926\u093e\u0928 \u0938\u094d\u092e\u0930\u0923 \u090f\u0935\u0902 \u092e\u0939\u0924\u094d\u0935\u092a\u0942\u0930\u094d\u0923 \u0938\u0942\u091a\u0928\u093e\u090f\u0902"

    invoke-virtual {v2, v5}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 925
    invoke-virtual {v2, v4}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    .line 926
    invoke-virtual {v2, v4}, Landroid/app/NotificationChannel;->enableLights(Z)V

    .line 927
    const-string v5, "#ea580c"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/app/NotificationChannel;->setLightColor(I)V

    .line 928
    invoke-virtual {v2, v4}, Landroid/app/NotificationChannel;->setLockscreenVisibility(I)V

    .line 929
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 932
    :cond_36
    new-instance v2, Landroid/content/Intent;

    const-class v5, Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {v2, p0, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 933
    const/high16 v5, 0x24000000

    invoke-virtual {v2, v5}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 934
    nop

    .line 935
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    long-to-int v6, v5

    .line 936
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x17

    if-lt v5, v7, :cond_51

    const/high16 v5, 0xc000000

    goto :goto_53

    :cond_51
    const/high16 v5, 0x8000000

    .line 934
    :goto_53
    invoke-static {p0, v6, v2, v5}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v2

    .line 940
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v5, v3, :cond_61

    .line 941
    new-instance v3, Landroid/app/Notification$Builder;

    invoke-direct {v3, p0, v1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_66

    .line 943
    :cond_61
    new-instance v3, Landroid/app/Notification$Builder;

    invoke-direct {v3, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 946
    :goto_66
    invoke-virtual {v3, p1}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object p1

    .line 947
    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object p1

    new-instance v1, Landroid/app/Notification$BigTextStyle;

    invoke-direct {v1}, Landroid/app/Notification$BigTextStyle;-><init>()V

    .line 948
    invoke-virtual {v1, p2}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;

    move-result-object p1

    .line 949
    const/high16 p2, 0x7f010000

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object p1

    .line 950
    const/4 p2, -0x1

    invoke-virtual {p1, p2}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object p1

    .line 951
    invoke-virtual {p1, v4}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    move-result-object p1

    .line 952
    invoke-virtual {p1, v4}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object p1

    .line 953
    invoke-virtual {p1, v2}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 955
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    const-wide/32 v1, 0xf4240

    rem-long/2addr p1, v1

    long-to-int p2, p1

    .line 956
    invoke-virtual {v3}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object p1

    invoke-virtual {v0, p2, p1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V
    :try_end_a1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_a1} :catch_a2

    goto :goto_a3

    .line 957
    :catch_a2
    move-exception p1

    :goto_a3
    nop

    .line 958
    return-void
.end method


# virtual methods
.method public downloadAndInstallApk(Ljava/lang/String;)V
    .registers 3

    .line 330
    if-eqz p1, :cond_16

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_16

    .line 332
    :cond_d
    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$4;

    invoke-direct {v0, p0, p1}, Lcom/yuvashaktigroup/app/MainActivity$4;-><init>(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 412
    return-void

    .line 330
    :cond_16
    :goto_16
    return-void
.end method

.method public generateAndSaveLedgerPdf(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 630
    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$9;

    invoke-direct {v0, p0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity$9;-><init>(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 864
    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 5

    .line 319
    const/16 v0, 0x3e9

    if-ne p1, v0, :cond_15

    .line 320
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mFilePathCallback:Landroid/webkit/ValueCallback;

    if-eqz p1, :cond_18

    .line 321
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mFilePathCallback:Landroid/webkit/ValueCallback;

    invoke-static {p2, p3}, Landroid/webkit/WebChromeClient$FileChooserParams;->parseResult(ILandroid/content/Intent;)[Landroid/net/Uri;

    move-result-object p2

    invoke-interface {p1, p2}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    .line 322
    const/4 p1, 0x0

    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mFilePathCallback:Landroid/webkit/ValueCallback;

    goto :goto_18

    .line 325
    :cond_15
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 327
    :cond_18
    :goto_18
    return-void
.end method

.method public onBackPressed()V
    .registers 8

    .line 962
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    if-eqz v0, :cond_12

    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_12

    .line 963
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V

    .line 964
    return-void

    .line 967
    :cond_12
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 968
    iget-wide v2, p0, Lcom/yuvashaktigroup/app/MainActivity;->mLastBackPressTime:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x7d0

    cmp-long v6, v2, v4

    if-gez v6, :cond_24

    .line 969
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    goto :goto_30

    .line 971
    :cond_24
    iput-wide v0, p0, Lcom/yuvashaktigroup/app/MainActivity;->mLastBackPressTime:J

    .line 972
    const-string v0, "\u092c\u093e\u0939\u0930 \u0928\u093f\u0915\u0932\u0928\u0947 \u0915\u0947 \u0932\u093f\u090f \u092a\u0941\u0928\u0903 \u092c\u0948\u0915 \u092c\u091f\u0928 \u0926\u092c\u093e\u090f\u0902"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 974
    :goto_30
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 6

    .line 137
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 138
    invoke-direct {p0}, Lcom/yuvashaktigroup/app/MainActivity;->checkAndRequestNotificationPermission()V

    .line 140
    new-instance p1, Landroid/webkit/WebView;

    invoke-direct {p1, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    .line 141
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    invoke-virtual {p0, p1}, Lcom/yuvashaktigroup/app/MainActivity;->setContentView(Landroid/view/View;)V

    .line 143
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    .line 144
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 145
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 146
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    .line 147
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 148
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 149
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    .line 150
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    .line 151
    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 152
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    .line 153
    const/4 v1, -0x1

    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    .line 154
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    .line 155
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setSupportMultipleWindows(Z)V

    .line 158
    invoke-virtual {p1}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object v1

    .line 159
    const-string v2, "; wv"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "Version/\\d+\\.\\d+\\s*"

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 160
    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 162
    :try_start_54
    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object p1

    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    invoke-virtual {p1, v1, v0}, Landroid/webkit/CookieManager;->setAcceptThirdPartyCookies(Landroid/webkit/WebView;Z)V
    :try_end_5d
    .catch Ljava/lang/Exception; {:try_start_54 .. :try_end_5d} :catch_5e

    goto :goto_5f

    .line 163
    :catch_5e
    move-exception p1

    :goto_5f
    nop

    .line 165
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;

    invoke-direct {v0, p0}, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    const-string v1, "AndroidApp"

    invoke-virtual {p1, v0, v1}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$1;

    invoke-direct {v0, p0}, Lcom/yuvashaktigroup/app/MainActivity$1;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    .line 174
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$2;

    invoke-direct {v0, p0}, Lcom/yuvashaktigroup/app/MainActivity$2;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 218
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$3;

    invoke-direct {v0, p0}, Lcom/yuvashaktigroup/app/MainActivity$3;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 314
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity;->mWebView:Landroid/webkit/WebView;

    const-string v0, "file:///android_asset/index.html"

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 315
    return-void
.end method

.method public printLedgerReport()V
    .registers 2

    .line 612
    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$8;

    invoke-direct {v0, p0}, Lcom/yuvashaktigroup/app/MainActivity$8;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 627
    return-void
.end method

.method public shareApplicationApk()V
    .registers 3

    .line 415
    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$5;

    invoke-direct {v0, p0}, Lcom/yuvashaktigroup/app/MainActivity$5;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 422
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/yuvashaktigroup/app/MainActivity$6;

    invoke-direct {v1, p0}, Lcom/yuvashaktigroup/app/MainActivity$6;-><init>(Lcom/yuvashaktigroup/app/MainActivity;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 526
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 527
    return-void
.end method

.method public shareGeneratedImage(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 530
    new-instance v0, Lcom/yuvashaktigroup/app/MainActivity$7;

    invoke-direct {v0, p0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity$7;-><init>(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 609
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass0 (com.yuvashaktigroup.app.MainActivity$0)
.class public final synthetic Lcom/yuvashaktigroup/app/MainActivity$0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"


# direct methods
.method public static synthetic m(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .registers 8

    .line 0
    :try_start_0
    const-class v0, Ljava/lang/Throwable;

    const-string v1, "addSuppressed"

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    const-class v4, Ljava/lang/Throwable;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v2, [Ljava/lang/Object;

    aput-object p1, v1, v5

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_17} :catch_18

    goto :goto_19

    :catch_18
    move-exception p0

    :goto_19
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass1 (com.yuvashaktigroup.app.MainActivity$1)
.class Lcom/yuvashaktigroup/app/MainActivity$1;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/webkit/DownloadListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 167
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$1;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onDownloadStart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .registers 7

    .line 170
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$1;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->downloadAndInstallApk(Ljava/lang/String;)V

    .line 171
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass2 (com.yuvashaktigroup.app.MainActivity$2)
.class Lcom/yuvashaktigroup/app/MainActivity$2;
.super Landroid/webkit/WebChromeClient;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 174
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreateWindow(Landroid/webkit/WebView;ZZLandroid/os/Message;)Z
    .registers 6

    .line 177
    invoke-virtual {p1}, Landroid/webkit/WebView;->getHitTestResult()Landroid/webkit/WebView$HitTestResult;

    move-result-object v0

    .line 178
    if-eqz v0, :cond_b

    invoke-virtual {v0}, Landroid/webkit/WebView$HitTestResult;->getExtra()Ljava/lang/String;

    move-result-object v0

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    .line 179
    :goto_c
    if-eqz v0, :cond_3a

    .line 180
    const-string p1, ".apk"

    invoke-virtual {v0, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 p2, 0x0

    if-nez p1, :cond_34

    const-string p1, "/releases/download/"

    invoke-virtual {v0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_20

    goto :goto_34

    .line 185
    :cond_20
    :try_start_20
    new-instance p1, Landroid/content/Intent;

    const-string p3, "android.intent.action.VIEW"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p4

    invoke-direct {p1, p3, p4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 186
    iget-object p3, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p3, p1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_30} :catch_31

    goto :goto_32

    .line 187
    :catch_31
    move-exception p1

    :goto_32
    nop

    .line 188
    return p2

    .line 181
    :cond_34
    :goto_34
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p1, v0}, Lcom/yuvashaktigroup/app/MainActivity;->downloadAndInstallApk(Ljava/lang/String;)V

    .line 182
    return p2

    .line 190
    :cond_3a
    invoke-super {p0, p1, p2, p3, p4}, Landroid/webkit/WebChromeClient;->onCreateWindow(Landroid/webkit/WebView;ZZLandroid/os/Message;)Z

    move-result p1

    return p1
.end method

.method public onShowFileChooser(Landroid/webkit/WebView;Landroid/webkit/ValueCallback;Landroid/webkit/WebChromeClient$FileChooserParams;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/webkit/WebView;",
            "Landroid/webkit/ValueCallback<",
            "[",
            "Landroid/net/Uri;",
            ">;",
            "Landroid/webkit/WebChromeClient$FileChooserParams;",
            ")Z"
        }
    .end annotation

    .line 195
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {p1}, Lcom/yuvashaktigroup/app/MainActivity;->access$200(Lcom/yuvashaktigroup/app/MainActivity;)Landroid/webkit/ValueCallback;

    move-result-object p1

    const/4 p3, 0x0

    if-eqz p1, :cond_12

    .line 196
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {p1}, Lcom/yuvashaktigroup/app/MainActivity;->access$200(Lcom/yuvashaktigroup/app/MainActivity;)Landroid/webkit/ValueCallback;

    move-result-object p1

    invoke-interface {p1, p3}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    .line 198
    :cond_12
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->access$202(Lcom/yuvashaktigroup/app/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;

    .line 200
    new-instance p1, Landroid/content/Intent;

    const-string p2, "android.intent.action.GET_CONTENT"

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 201
    const-string p2, "android.intent.category.OPENABLE"

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 202
    const-string p2, "image/*"

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 204
    new-instance p2, Landroid/content/Intent;

    const-string v0, "android.intent.action.CHOOSER"

    invoke-direct {p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 205
    const-string v0, "android.intent.extra.INTENT"

    invoke-virtual {p2, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 206
    const-string p1, "android.intent.extra.TITLE"

    const-string v0, "\u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u092b\u094b\u091f\u094b \u091a\u0941\u0928\u0947\u0902"

    invoke-virtual {p2, p1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 209
    :try_start_3b
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const/16 v0, 0x3e9

    invoke-virtual {p1, p2, v0}, Lcom/yuvashaktigroup/app/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_42} :catch_44

    .line 210
    const/4 p1, 0x1

    return p1

    .line 211
    :catch_44
    move-exception p1

    .line 212
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$2;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {p1, p3}, Lcom/yuvashaktigroup/app/MainActivity;->access$202(Lcom/yuvashaktigroup/app/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;

    .line 213
    const/4 p1, 0x0

    return p1
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass3 (com.yuvashaktigroup.app.MainActivity$3)
.class Lcom/yuvashaktigroup/app/MainActivity$3;
.super Landroid/webkit/WebViewClient;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 218
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method


# virtual methods
.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .registers 8

    .line 221
    const/4 v0, 0x0

    if-nez p2, :cond_4

    return v0

    .line 224
    :cond_4
    const-string v1, "upi://"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const-string v2, "android.intent.action.VIEW"

    const/4 v3, 0x1

    if-nez v1, :cond_11d

    const-string v1, "phonepe://"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_19

    goto/16 :goto_11d

    .line 236
    :cond_19
    const-string v1, "intent://"

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_53

    .line 238
    :try_start_21
    invoke-static {p2, v3}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v1

    .line 239
    if-eqz v1, :cond_45

    .line 240
    iget-object v4, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v4}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    invoke-virtual {v4, v1, v0}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v4

    if-eqz v4, :cond_39

    .line 241
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p1, v1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V

    .line 242
    return v3

    .line 244
    :cond_39
    const-string v4, "browser_fallback_url"

    invoke-virtual {v1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 245
    if-eqz v1, :cond_45

    .line 246
    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_44
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_44} :catch_46

    .line 247
    return v3

    .line 253
    :cond_45
    goto :goto_53

    .line 250
    :catch_46
    move-exception p1

    .line 251
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "\u0910\u092a \u0916\u094b\u0932\u0928\u0947 \u092e\u0947\u0902 \u0905\u0938\u092e\u0930\u094d\u0925"

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 252
    return v3

    .line 257
    :cond_53
    :goto_53
    const-string p1, ".apk"

    invoke-virtual {p2, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_117

    const-string p1, "/releases/download/"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_65

    goto/16 :goto_117

    .line 263
    :cond_65
    const-string p1, "tel:"

    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_8b

    .line 265
    :try_start_6d
    new-instance p1, Landroid/content/Intent;

    const-string v1, "android.intent.action.DIAL"

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {p1, v1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 266
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_7d
    .catch Ljava/lang/Exception; {:try_start_6d .. :try_end_7d} :catch_7e

    .line 267
    return v3

    .line 268
    :catch_7e
    move-exception p1

    .line 269
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "\u0915\u0949\u0932 \u0915\u0930\u0928\u0947 \u092e\u0947\u0902 \u0905\u0938\u092e\u0930\u094d\u0925"

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 270
    return v3

    .line 275
    :cond_8b
    const-string p1, "chat.whatsapp.com"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_fb

    const-string p1, "wa.me"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_fb

    const-string p1, "api.whatsapp.com"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_fb

    const-string p1, "whatsapp://"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_ac

    goto :goto_fb

    .line 287
    :cond_ac
    const-string p1, "instagram.com"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_d0

    .line 289
    :try_start_b4
    new-instance p1, Landroid/content/Intent;

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {p1, v2, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 290
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_c2
    .catch Ljava/lang/Exception; {:try_start_b4 .. :try_end_c2} :catch_c3

    .line 291
    return v3

    .line 292
    :catch_c3
    move-exception p1

    .line 293
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "\u0907\u0902\u0938\u094d\u091f\u093e\u0917\u094d\u0930\u093e\u092e \u0916\u094b\u0932\u0928\u0947 \u092e\u0947\u0902 \u0905\u0938\u092e\u0930\u094d\u0925"

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 294
    return v3

    .line 299
    :cond_d0
    const-string p1, "file:"

    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_fa

    const-string p1, "http:"

    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_fa

    const-string p1, "https:"

    invoke-virtual {p2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_e9

    goto :goto_fa

    .line 304
    :cond_e9
    :try_start_e9
    new-instance p1, Landroid/content/Intent;

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {p1, v2, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 305
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_f7
    .catch Ljava/lang/Exception; {:try_start_e9 .. :try_end_f7} :catch_f8

    .line 306
    return v3

    .line 307
    :catch_f8
    move-exception p1

    .line 308
    return v0

    .line 300
    :cond_fa
    :goto_fa
    return v0

    .line 277
    :cond_fb
    :goto_fb
    :try_start_fb
    new-instance p1, Landroid/content/Intent;

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {p1, v2, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 278
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_109
    .catch Ljava/lang/Exception; {:try_start_fb .. :try_end_109} :catch_10a

    .line 279
    return v3

    .line 280
    :catch_10a
    move-exception p1

    .line 281
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "\u0935\u094d\u0939\u093e\u091f\u094d\u0938\u090f\u092a \u0909\u092a\u0932\u092c\u094d\u0927 \u0928\u0939\u0940\u0902 \u0939\u0948"

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 282
    return v3

    .line 258
    :cond_117
    :goto_117
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->downloadAndInstallApk(Ljava/lang/String;)V

    .line 259
    return v3

    .line 226
    :cond_11d
    :goto_11d
    :try_start_11d
    new-instance p1, Landroid/content/Intent;

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    invoke-direct {p1, v2, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 227
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_12b
    .catch Ljava/lang/Exception; {:try_start_11d .. :try_end_12b} :catch_12c

    .line 228
    return v3

    .line 229
    :catch_12c
    move-exception p1

    .line 230
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$3;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "PhonePe / UPI \u0910\u092a \u0928\u0939\u0940\u0902 \u092e\u093f\u0932\u093e"

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 231
    return v3
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass4 (com.yuvashaktigroup.app.MainActivity$4)
.class Lcom/yuvashaktigroup/app/MainActivity$4;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->downloadAndInstallApk(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;)V
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 332
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    iput-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->val$url:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    .line 336
    const/4 v0, 0x0

    :try_start_1
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v2, "\u0905\u092a\u0921\u0947\u091f \u0921\u093e\u0909\u0928\u0932\u094b\u0921 \u0936\u0941\u0930\u0942 \u0939\u094b \u0930\u0939\u093e \u0939\u0948..."

    invoke-static {v1, v2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 338
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    const/4 v3, 0x1

    if-lt v1, v2, :cond_56

    .line 339
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v1}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/pm/PackageManager;->canRequestPackageInstalls()Z

    move-result v1
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1d} :catch_c2

    if-nez v1, :cond_56

    .line 341
    :try_start_1f
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "package:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v5}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v1, v2, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 342
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v2, v1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V

    .line 343
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v2, "\u0915\u0943\u092a\u092f\u093e \u0910\u092a \u0905\u092a\u0921\u0947\u091f \u0907\u0902\u0938\u094d\u091f\u0949\u0932 \u0915\u0940 \u0905\u0928\u0941\u092e\u0924\u093f \u0926\u0947\u0902"

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V
    :try_end_53
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_53} :catch_54

    goto :goto_55

    .line 344
    :catch_54
    move-exception v1

    :goto_55
    nop

    .line 348
    :cond_56
    :try_start_56
    sget-object v1, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_56 .. :try_end_5c} :catch_c2

    .line 349
    const-string v2, "YuvaShaktiGroup.apk"

    if-eqz v1, :cond_6e

    .line 350
    :try_start_60
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 351
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_6e

    .line 352
    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    .line 356
    :cond_6e
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->val$url:Ljava/lang/String;

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 357
    new-instance v4, Landroid/app/DownloadManager$Request;

    invoke-direct {v4, v1}, Landroid/app/DownloadManager$Request;-><init>(Landroid/net/Uri;)V

    .line 358
    const-string v1, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a - \u0928\u092f\u093e \u0905\u092a\u0921\u0947\u091f"

    invoke-virtual {v4, v1}, Landroid/app/DownloadManager$Request;->setTitle(Ljava/lang/CharSequence;)Landroid/app/DownloadManager$Request;

    .line 359
    const-string v1, "\u0928\u0935\u0940\u0928\u0924\u092e APK \u0921\u093e\u0909\u0928\u0932\u094b\u0921 \u0939\u094b \u0930\u0939\u093e \u0939\u0948..."

    invoke-virtual {v4, v1}, Landroid/app/DownloadManager$Request;->setDescription(Ljava/lang/CharSequence;)Landroid/app/DownloadManager$Request;

    .line 360
    const-string v1, "application/vnd.android.package-archive"

    invoke-virtual {v4, v1}, Landroid/app/DownloadManager$Request;->setMimeType(Ljava/lang/String;)Landroid/app/DownloadManager$Request;

    .line 361
    invoke-virtual {v4, v3}, Landroid/app/DownloadManager$Request;->setNotificationVisibility(I)Landroid/app/DownloadManager$Request;

    .line 362
    sget-object v1, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-virtual {v4, v1, v2}, Landroid/app/DownloadManager$Request;->setDestinationInExternalPublicDir(Ljava/lang/String;Ljava/lang/String;)Landroid/app/DownloadManager$Request;

    .line 364
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v2, "download"

    invoke-virtual {v1, v2}, Lcom/yuvashaktigroup/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/DownloadManager;

    .line 365
    if-eqz v1, :cond_c1

    .line 366
    invoke-virtual {v1, v4}, Landroid/app/DownloadManager;->enqueue(Landroid/app/DownloadManager$Request;)J

    move-result-wide v2

    .line 368
    new-instance v4, Lcom/yuvashaktigroup/app/MainActivity$4$1;

    invoke-direct {v4, p0, v2, v3, v1}, Lcom/yuvashaktigroup/app/MainActivity$4$1;-><init>(Lcom/yuvashaktigroup/app/MainActivity$4;JLandroid/app/DownloadManager;)V

    .line 396
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_a7
    .catch Ljava/lang/Exception; {:try_start_60 .. :try_end_a7} :catch_c2

    .line 399
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    .line 396
    const-string v3, "android.intent.action.DOWNLOAD_COMPLETE"

    const/16 v5, 0x21

    if-lt v1, v5, :cond_b9

    .line 397
    :try_start_af
    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    invoke-virtual {v2, v4, v1, v3}, Lcom/yuvashaktigroup/app/MainActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    goto :goto_c1

    .line 399
    :cond_b9
    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v4, v1}, Lcom/yuvashaktigroup/app/MainActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_c1
    .catch Ljava/lang/Exception; {:try_start_af .. :try_end_c1} :catch_c2

    .line 409
    :cond_c1
    :goto_c1
    goto :goto_f7

    .line 402
    :catch_c2
    move-exception v1

    .line 404
    :try_start_c3
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->val$url:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 405
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v2, v1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_d5
    .catch Ljava/lang/Exception; {:try_start_c3 .. :try_end_d5} :catch_d6

    .line 408
    goto :goto_f7

    .line 406
    :catch_d6
    move-exception v1

    .line 407
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u0921\u093e\u0909\u0928\u0932\u094b\u0921 \u0924\u094d\u0930\u0941\u091f\u093f: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 410
    :goto_f7
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass4.AnonymousClass1 (com.yuvashaktigroup.app.MainActivity$4$1)
.class Lcom/yuvashaktigroup/app/MainActivity$4$1;
.super Landroid/content/BroadcastReceiver;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity$4;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/yuvashaktigroup/app/MainActivity$4;

.field final synthetic val$downloadId:J

.field final synthetic val$manager:Landroid/app/DownloadManager;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity$4;JLandroid/app/DownloadManager;)V
    .registers 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .line 368
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$4;

    iput-wide p2, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->val$downloadId:J

    iput-object p4, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->val$manager:Landroid/app/DownloadManager;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 7

    .line 371
    const-string v0, "extra_download_id"

    const-wide/16 v1, -0x1

    invoke-virtual {p2, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    .line 372
    iget-wide v2, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->val$downloadId:J

    cmp-long p2, v0, v2

    if-nez p2, :cond_6e

    .line 374
    :try_start_e
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->val$manager:Landroid/app/DownloadManager;

    iget-wide v0, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->val$downloadId:J

    invoke-virtual {p2, v0, v1}, Landroid/app/DownloadManager;->getUriForDownloadedFile(J)Landroid/net/Uri;

    move-result-object p2

    .line 375
    new-instance v0, Ljava/io/File;

    sget-object v1, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const-string v2, "YuvaShaktiGroup.apk"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 376
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_2a} :catch_55

    .line 377
    const-string v2, "application/vnd.android.package-archive"

    if-eqz p2, :cond_32

    .line 378
    :try_start_2e
    invoke-virtual {v1, p2, v2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_4b

    .line 379
    :cond_32
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p2

    if-eqz p2, :cond_4b

    .line 380
    new-instance p2, Landroid/os/StrictMode$VmPolicy$Builder;

    invoke-direct {p2}, Landroid/os/StrictMode$VmPolicy$Builder;-><init>()V

    .line 381
    invoke-virtual {p2}, Landroid/os/StrictMode$VmPolicy$Builder;->build()Landroid/os/StrictMode$VmPolicy;

    move-result-object p2

    invoke-static {p2}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    .line 382
    invoke-static {v0}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {v1, p2, v2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    .line 384
    :cond_4b
    :goto_4b
    const p2, 0x10000001

    invoke-virtual {v1, p2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 385
    invoke-virtual {p1, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_2e .. :try_end_54} :catch_55

    .line 388
    goto :goto_64

    .line 386
    :catch_55
    move-exception p1

    .line 387
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$4;

    iget-object p1, p1, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "\u0921\u093e\u0909\u0928\u0932\u094b\u0921 \u092a\u0942\u0930\u094d\u0923 \u0939\u0941\u0906! \u0921\u093e\u0909\u0928\u0932\u094b\u0921\u094d\u0938 \u092b\u094b\u0932\u094d\u0921\u0930 \u0938\u0947 \u0907\u0902\u0938\u094d\u091f\u0949\u0932 \u0915\u0930\u0947\u0902"

    const/4 v0, 0x1

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 390
    :goto_64
    :try_start_64
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$4$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$4;

    iget-object p1, p1, Lcom/yuvashaktigroup/app/MainActivity$4;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p1, p0}, Lcom/yuvashaktigroup/app/MainActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_64 .. :try_end_6b} :catch_6c

    goto :goto_6d

    .line 391
    :catch_6c
    move-exception p1

    :goto_6d
    nop

    .line 393
    :cond_6e
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass5 (com.yuvashaktigroup.app.MainActivity$5)
.class Lcom/yuvashaktigroup/app/MainActivity$5;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->shareApplicationApk()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 415
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$5;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 418
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$5;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v1, "\ud83d\udce6 \u090f\u092a\u094d\u0932\u093f\u0915\u0947\u0936\u0928 APK \u0924\u0948\u092f\u093e\u0930 \u0939\u094b \u0930\u0939\u0940 \u0939\u0948..."

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 419
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass6 (com.yuvashaktigroup.app.MainActivity$6)
.class Lcom/yuvashaktigroup/app/MainActivity$6;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->shareApplicationApk()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 422
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 10

    .line 426
    const-string v0, "YuvaShaktiGroup.apk"

    const-string v1, "shared_apk"

    :try_start_4
    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v3}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageCodePath()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 427
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_1f

    invoke-virtual {v2}, Ljava/io/File;->length()J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v7, v3, v5

    if-nez v7, :cond_2c

    .line 428
    :cond_1f
    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v3}, Lcom/yuvashaktigroup/app/MainActivity;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 431
    :cond_2c
    new-instance v3, Ljava/io/File;

    iget-object v4, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v4}, Lcom/yuvashaktigroup/app/MainActivity;->getCacheDir()Ljava/io/File;

    move-result-object v4

    invoke-direct {v3, v4, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 432
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    if-nez v4, :cond_40

    .line 433
    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    .line 435
    :cond_40
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v3, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 437
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_57

    invoke-virtual {v4}, Ljava/io/File;->length()J

    move-result-wide v5

    invoke-virtual {v2}, Ljava/io/File;->length()J

    move-result-wide v7

    cmp-long v3, v5, v7

    if-eqz v3, :cond_5c

    .line 438
    :cond_57
    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v3, v2, v4}, Lcom/yuvashaktigroup/app/MainActivity;->access$300(Lcom/yuvashaktigroup/app/MainActivity;Ljava/io/File;Ljava/io/File;)V
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_5c} :catch_c3

    .line 442
    :cond_5c
    :try_start_5c
    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v3}, Lcom/yuvashaktigroup/app/MainActivity;->getExternalCacheDir()Ljava/io/File;

    move-result-object v3

    .line 443
    if-eqz v3, :cond_90

    .line 444
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v3, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 445
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_72

    invoke-virtual {v4}, Ljava/io/File;->mkdirs()Z

    .line 446
    :cond_72
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v4, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 447
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_89

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v3

    invoke-virtual {v2}, Ljava/io/File;->length()J

    move-result-wide v5

    cmp-long v0, v3, v5

    if-eqz v0, :cond_90

    .line 448
    :cond_89
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v0, v2, v1}, Lcom/yuvashaktigroup/app/MainActivity;->access$300(Lcom/yuvashaktigroup/app/MainActivity;Ljava/io/File;Ljava/io/File;)V
    :try_end_8e
    .catch Ljava/lang/Exception; {:try_start_5c .. :try_end_8e} :catch_8f

    goto :goto_90

    .line 451
    :catch_8f
    move-exception v0

    :cond_90
    :goto_90
    nop

    .line 454
    :try_start_91
    new-instance v0, Ljava/io/File;

    const-string v1, "/sdcard/Download/YuvaShaktiGroup.apk"

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 455
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_aa

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v3

    invoke-virtual {v2}, Ljava/io/File;->length()J

    move-result-wide v5

    cmp-long v1, v3, v5

    if-eqz v1, :cond_b1

    .line 456
    :cond_aa
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v1, v2, v0}, Lcom/yuvashaktigroup/app/MainActivity;->access$300(Lcom/yuvashaktigroup/app/MainActivity;Ljava/io/File;Ljava/io/File;)V
    :try_end_af
    .catch Ljava/lang/Exception; {:try_start_91 .. :try_end_af} :catch_b0

    goto :goto_b1

    .line 458
    :catch_b0
    move-exception v0

    :cond_b1
    :goto_b1
    nop

    .line 460
    :try_start_b2
    const-string v0, "content://com.yuvashaktigroup.app.fileprovider/shared_apk/YuvaShaktiGroup.apk"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 462
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v2, Lcom/yuvashaktigroup/app/MainActivity$6$1;

    invoke-direct {v2, p0, v0}, Lcom/yuvashaktigroup/app/MainActivity$6$1;-><init>(Lcom/yuvashaktigroup/app/MainActivity$6;Landroid/net/Uri;)V

    invoke-virtual {v1, v2}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_c2
    .catch Ljava/lang/Exception; {:try_start_b2 .. :try_end_c2} :catch_c3

    .line 524
    goto :goto_ce

    .line 517
    :catch_c3
    move-exception v0

    .line 518
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v2, Lcom/yuvashaktigroup/app/MainActivity$6$2;

    invoke-direct {v2, p0, v0}, Lcom/yuvashaktigroup/app/MainActivity$6$2;-><init>(Lcom/yuvashaktigroup/app/MainActivity$6;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 525
    :goto_ce
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass6.AnonymousClass1 (com.yuvashaktigroup.app.MainActivity$6$1)
.class Lcom/yuvashaktigroup/app/MainActivity$6$1;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity$6;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

.field final synthetic val$apkUri:Landroid/net/Uri;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity$6;Landroid/net/Uri;)V
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 462
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iput-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->val$apkUri:Landroid/net/Uri;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 10

    .line 466
    const/4 v0, 0x1

    :try_start_1
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.SEND"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 467
    const-string v2, "application/vnd.android.package-archive"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 468
    const-string v2, "android.intent.extra.STREAM"

    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->val$apkUri:Landroid/net/Uri;

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 470
    const-string v2, "\ud83d\udea9 *\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a (\u092d\u093e\u091f\u0940 \u092a\u0930\u093f\u0935\u093e\u0930 \u2022 \u0915\u0941\u091a\u0947\u0930\u093e)* \ud83d\udea9\n\n\u0906\u0927\u093f\u0915\u093e\u0930\u093f\u0915 \u092a\u0930\u093f\u0935\u093e\u0930 \u092a\u094d\u0930\u092c\u0902\u0927\u0928 \u090f\u0935\u0902 \u092c\u0939\u0940-\u0916\u093e\u0924\u093e \u090f\u092a\u094d\u0932\u093f\u0915\u0947\u0936\u0928 (APK \u092b\u093e\u0907\u0932)\u0964\n\n\ud83d\udcf2 *\u0938\u0940\u0927\u093e APK \u0921\u093e\u0909\u0928\u0932\u094b\u0921 \u0932\u093f\u0902\u0915:*\nhttps://github.com/revantram/yuva-shakti-app/releases/latest/download/YuvaShaktiGroup.apk\n\n\ud83d\udcac *\u0935\u094d\u0939\u093e\u091f\u094d\u0938\u090f\u092a \u0917\u094d\u0930\u0941\u092a \u0932\u093f\u0902\u0915:*\nhttps://chat.whatsapp.com/JOVKSohSoBHEokrCXOSkTh"

    .line 477
    const-string v3, "android.intent.extra.TEXT"

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 478
    const-string v2, "android.intent.extra.SUBJECT"

    const-string v3, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a \u0910\u092a APK"

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 480
    const-string v2, "YuvaShaktiGroup.apk"

    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->val$apkUri:Landroid/net/Uri;

    invoke-static {v2, v3}, Landroid/content/ClipData;->newRawUri(Ljava/lang/CharSequence;Landroid/net/Uri;)Landroid/content/ClipData;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    .line 481
    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 483
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v2, v2, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v2}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/high16 v3, 0x10000

    invoke-virtual {v2, v1, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    .line 484
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_42
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/pm/ResolveInfo;

    .line 485
    iget-object v3, v3, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    .line 486
    iget-object v4, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v4, v4, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    iget-object v5, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->val$apkUri:Landroid/net/Uri;

    invoke-virtual {v4, v3, v5, v0}, Lcom/yuvashaktigroup/app/MainActivity;->grantUriPermission(Ljava/lang/String;Landroid/net/Uri;I)V

    .line 487
    goto :goto_42

    .line 489
    :cond_5c
    nop

    .line 490
    const/4 v2, 0x2

    new-array v3, v2, [Ljava/lang/String;

    const-string v4, "com.whatsapp"

    const/4 v5, 0x0

    aput-object v4, v3, v5

    const-string v4, "com.whatsapp.w4b"

    aput-object v4, v3, v0

    const/4 v4, 0x0

    :goto_6a
    if-ge v4, v2, :cond_8c

    aget-object v6, v3, v4
    :try_end_6e
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_6e} :catch_af

    .line 492
    :try_start_6e
    iget-object v7, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v7, v7, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v7}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v7

    invoke-virtual {v7, v6, v5}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 493
    invoke-virtual {v1, v6}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 494
    iget-object v7, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v7, v7, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    iget-object v8, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->val$apkUri:Landroid/net/Uri;

    invoke-virtual {v7, v6, v8, v0}, Lcom/yuvashaktigroup/app/MainActivity;->grantUriPermission(Ljava/lang/String;Landroid/net/Uri;I)V
    :try_end_85
    .catch Ljava/lang/Exception; {:try_start_6e .. :try_end_85} :catch_88

    .line 495
    nop

    .line 496
    const/4 v5, 0x1

    goto :goto_8c

    .line 497
    :catch_88
    move-exception v6

    .line 490
    add-int/lit8 v4, v4, 0x1

    goto :goto_6a

    .line 500
    :cond_8c
    :goto_8c
    const/4 v2, 0x0

    if-nez v5, :cond_92

    .line 501
    :try_start_8f
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;
    :try_end_92
    .catch Ljava/lang/Exception; {:try_start_8f .. :try_end_92} :catch_af

    .line 505
    :cond_92
    :try_start_92
    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v3, v3, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v3, v1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_99
    .catch Ljava/lang/Exception; {:try_start_92 .. :try_end_99} :catch_9a

    .line 511
    goto :goto_ae

    .line 506
    :catch_9a
    move-exception v3

    .line 507
    :try_start_9b
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 508
    const-string v2, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0910\u092a APK \u0936\u0947\u092f\u0930 \u0915\u0930\u0947\u0902"

    invoke-static {v1, v2}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v1

    .line 509
    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 510
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v2, v2, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v2, v1}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_ae
    .catch Ljava/lang/Exception; {:try_start_9b .. :try_end_ae} :catch_af

    .line 514
    :goto_ae
    goto :goto_d2

    .line 512
    :catch_af
    move-exception v1

    .line 513
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$6$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v2, v2, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u0936\u0947\u092f\u0930 \u0924\u094d\u0930\u0941\u091f\u093f: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 515
    :goto_d2
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass6.AnonymousClass2 (com.yuvashaktigroup.app.MainActivity$6$2)
.class Lcom/yuvashaktigroup/app/MainActivity$6$2;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity$6;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

.field final synthetic val$e:Ljava/lang/Exception;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity$6;Ljava/lang/Exception;)V
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 518
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$6$2;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iput-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$6$2;->val$e:Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 521
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$6$2;->this$1:Lcom/yuvashaktigroup/app/MainActivity$6;

    iget-object v0, v0, Lcom/yuvashaktigroup/app/MainActivity$6;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "APK \u0924\u0948\u092f\u093e\u0930 \u0915\u0930\u0928\u0947 \u092e\u0947\u0902 \u0924\u094d\u0930\u0941\u091f\u093f: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$6$2;->val$e:Ljava/lang/Exception;

    invoke-virtual {v2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 522
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass7 (com.yuvashaktigroup.app.MainActivity$7)
.class Lcom/yuvashaktigroup/app/MainActivity$7;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->shareGeneratedImage(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;

.field final synthetic val$base64Data:Ljava/lang/String;

.field final synthetic val$caption:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 530
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    iput-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->val$base64Data:Ljava/lang/String;

    iput-object p3, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->val$caption:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 13

    .line 534
    const-string v0, "image/jpeg"

    const-string v1, ".jpg"

    const-string v2, "suvichar_"

    const-string v3, ","

    const/4 v4, 0x0

    :try_start_9
    iget-object v5, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->val$base64Data:Ljava/lang/String;

    .line 535
    invoke-virtual {v5, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v7, 0x1

    if-eqz v6, :cond_1b

    .line 536
    invoke-virtual {v5, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v3

    add-int/2addr v3, v7

    invoke-virtual {v5, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    .line 538
    :cond_1b
    invoke-static {v5, v4}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v3
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_1f} :catch_16f

    .line 542
    const/4 v5, 0x0

    :try_start_20
    new-instance v6, Ljava/io/File;

    sget-object v8, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    invoke-static {v8}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v8

    const-string v9, "YuvaShakti"

    invoke-direct {v6, v8, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 543
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v8

    if-nez v8, :cond_36

    .line 544
    invoke-virtual {v6}, Ljava/io/File;->mkdirs()Z

    .line 546
    :cond_36
    new-instance v8, Ljava/io/File;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-virtual {v9, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v6, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 547
    new-instance v6, Ljava/io/FileOutputStream;

    invoke-direct {v6, v8}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 548
    invoke-virtual {v6, v3}, Ljava/io/FileOutputStream;->write([B)V

    .line 549
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->flush()V

    .line 550
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V

    .line 551
    iget-object v6, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v8

    new-array v9, v7, [Ljava/lang/String;

    aput-object v8, v9, v4

    new-array v8, v7, [Ljava/lang/String;

    aput-object v0, v8, v4

    invoke-static {v6, v9, v8, v5}, Landroid/media/MediaScannerConnection;->scanFile(Landroid/content/Context;[Ljava/lang/String;[Ljava/lang/String;Landroid/media/MediaScannerConnection$OnScanCompletedListener;)V
    :try_end_73
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_73} :catch_74

    goto :goto_75

    .line 552
    :catch_74
    move-exception v6

    :goto_75
    nop

    .line 555
    :try_start_76
    new-instance v6, Ljava/io/File;

    iget-object v8, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v8}, Lcom/yuvashaktigroup/app/MainActivity;->getCacheDir()Ljava/io/File;

    move-result-object v8

    const-string v9, "shared_images"

    invoke-direct {v6, v8, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 556
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v8

    if-nez v8, :cond_8c

    .line 557
    invoke-virtual {v6}, Ljava/io/File;->mkdirs()Z

    .line 559
    :cond_8c
    new-instance v8, Ljava/io/File;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    invoke-virtual {v2, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v8, v6, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 560
    new-instance v1, Ljava/io/FileOutputStream;

    invoke-direct {v1, v8}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 561
    invoke-virtual {v1, v3}, Ljava/io/FileOutputStream;->write([B)V

    .line 562
    invoke-virtual {v1}, Ljava/io/FileOutputStream;->flush()V

    .line 563
    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V

    .line 565
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "content://com.yuvashaktigroup.app.fileprovider/shared_images/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v8}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 567
    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.SEND"

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 568
    invoke-virtual {v2, v0}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 569
    const-string v0, "android.intent.extra.STREAM"

    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 570
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->val$caption:Ljava/lang/String;

    if-eqz v0, :cond_f5

    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->val$caption:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_f5

    .line 571
    const-string v0, "android.intent.extra.TEXT"

    iget-object v3, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->val$caption:Ljava/lang/String;

    invoke-virtual {v2, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 573
    :cond_f5
    const-string v0, "suvichar.jpg"

    invoke-static {v0, v1}, Landroid/content/ClipData;->newRawUri(Ljava/lang/CharSequence;Landroid/net/Uri;)Landroid/content/ClipData;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    .line 574
    invoke-virtual {v2, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 576
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v0}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/high16 v3, 0x10000

    invoke-virtual {v0, v2, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v0

    .line 577
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_111
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_127

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/pm/ResolveInfo;

    .line 578
    iget-object v3, v3, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    .line 579
    iget-object v6, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v6, v3, v1, v7}, Lcom/yuvashaktigroup/app/MainActivity;->grantUriPermission(Ljava/lang/String;Landroid/net/Uri;I)V

    .line 580
    goto :goto_111

    .line 582
    :cond_127
    nop

    .line 583
    const/4 v0, 0x2

    new-array v3, v0, [Ljava/lang/String;

    const-string v6, "com.whatsapp"

    aput-object v6, v3, v4

    const-string v6, "com.whatsapp.w4b"

    aput-object v6, v3, v7

    const/4 v6, 0x0

    :goto_134
    if-ge v6, v0, :cond_150

    aget-object v8, v3, v6
    :try_end_138
    .catch Ljava/lang/Exception; {:try_start_76 .. :try_end_138} :catch_16f

    .line 585
    :try_start_138
    iget-object v9, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v9}, Lcom/yuvashaktigroup/app/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v9

    invoke-virtual {v9, v8, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 586
    invoke-virtual {v2, v8}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 587
    iget-object v9, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v9, v8, v1, v7}, Lcom/yuvashaktigroup/app/MainActivity;->grantUriPermission(Ljava/lang/String;Landroid/net/Uri;I)V
    :try_end_149
    .catch Ljava/lang/Exception; {:try_start_138 .. :try_end_149} :catch_14c

    .line 588
    nop

    .line 589
    const/4 v0, 0x1

    goto :goto_151

    .line 590
    :catch_14c
    move-exception v8

    .line 583
    add-int/lit8 v6, v6, 0x1

    goto :goto_134

    :cond_150
    const/4 v0, 0x0

    .line 592
    :goto_151
    if-nez v0, :cond_156

    .line 593
    :try_start_153
    invoke-virtual {v2, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;
    :try_end_156
    .catch Ljava/lang/Exception; {:try_start_153 .. :try_end_156} :catch_16f

    .line 597
    :cond_156
    :try_start_156
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v0, v2}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_15b
    .catch Ljava/lang/Exception; {:try_start_156 .. :try_end_15b} :catch_15c

    .line 603
    goto :goto_16e

    .line 598
    :catch_15c
    move-exception v0

    .line 599
    :try_start_15d
    invoke-virtual {v2, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 600
    const-string v0, "\u0938\u0941\u0935\u093f\u091a\u093e\u0930 \u092b\u094b\u091f\u094b \u0936\u0947\u092f\u0930 \u0915\u0930\u0947\u0902"

    invoke-static {v2, v0}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    .line 601
    invoke-virtual {v0, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 602
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v1, v0}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_16e
    .catch Ljava/lang/Exception; {:try_start_15d .. :try_end_16e} :catch_16f

    .line 606
    :goto_16e
    goto :goto_190

    .line 604
    :catch_16f
    move-exception v0

    .line 605
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$7;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u092b\u094b\u091f\u094b \u0936\u0947\u092f\u0930 \u0915\u0930\u0928\u0947 \u092e\u0947\u0902 \u0924\u094d\u0930\u0941\u091f\u093f: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 607
    :goto_190
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass8 (com.yuvashaktigroup.app.MainActivity$8)
.class Lcom/yuvashaktigroup/app/MainActivity$8;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->printLedgerReport()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 612
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$8;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 616
    :try_start_0
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$8;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v1, "print"

    invoke-virtual {v0, v1}, Lcom/yuvashaktigroup/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/print/PrintManager;

    .line 617
    if-eqz v0, :cond_24

    .line 618
    const-string v1, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a - \u092c\u0939\u0940-\u0916\u093e\u0924\u093e \u0930\u093f\u092a\u094b\u0930\u094d\u091f"

    .line 619
    iget-object v2, p0, Lcom/yuvashaktigroup/app/MainActivity$8;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v2}, Lcom/yuvashaktigroup/app/MainActivity;->access$400(Lcom/yuvashaktigroup/app/MainActivity;)Landroid/webkit/WebView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/webkit/WebView;->createPrintDocumentAdapter(Ljava/lang/String;)Landroid/print/PrintDocumentAdapter;

    move-result-object v2

    .line 620
    new-instance v3, Landroid/print/PrintAttributes$Builder;

    invoke-direct {v3}, Landroid/print/PrintAttributes$Builder;-><init>()V

    invoke-virtual {v3}, Landroid/print/PrintAttributes$Builder;->build()Landroid/print/PrintAttributes;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/print/PrintManager;->print(Ljava/lang/String;Landroid/print/PrintDocumentAdapter;Landroid/print/PrintAttributes;)Landroid/print/PrintJob;
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_24} :catch_25

    .line 624
    :cond_24
    goto :goto_47

    .line 622
    :catch_25
    move-exception v0

    .line 623
    iget-object v1, p0, Lcom/yuvashaktigroup/app/MainActivity$8;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u092a\u094d\u0930\u093f\u0902\u091f / \u092a\u0940\u0921\u0940\u090f\u092b \u0924\u0948\u092f\u093e\u0930 \u0915\u0930\u0928\u0947 \u092e\u0947\u0902 \u0905\u0938\u092e\u0930\u094d\u0925: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    invoke-static {v1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 625
    :goto_47
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.AnonymousClass9 (com.yuvashaktigroup.app.MainActivity$9)
.class Lcom/yuvashaktigroup/app/MainActivity$9;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity;->generateAndSaveLedgerPdf(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;

.field final synthetic val$summaryJson:Ljava/lang/String;

.field final synthetic val$transactionsJson:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            null,
            null,
            null
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 630
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    iput-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$9;->val$summaryJson:Ljava/lang/String;

    iput-object p3, p0, Lcom/yuvashaktigroup/app/MainActivity$9;->val$transactionsJson:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 37

    .line 633
    move-object/from16 v1, p0

    const-string v0, ".pdf"

    const-string v2, "date"

    const-string v3, "#b91c1c"

    const-string v4, "#047857"

    const-string v5, "%,d"

    const-string v6, "\u20b9"

    const-string v7, ""

    .line 635
    :try_start_10
    new-instance v10, Lorg/json/JSONObject;

    iget-object v11, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->val$summaryJson:Ljava/lang/String;
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_14} :catch_62a
    .catchall {:try_start_10 .. :try_end_14} :catchall_626

    if-eqz v11, :cond_21

    :try_start_16
    iget-object v11, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->val$summaryJson:Ljava/lang/String;
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_18} :catch_1d
    .catchall {:try_start_16 .. :try_end_18} :catchall_19

    goto :goto_23

    .line 858
    :catchall_19
    move-exception v0

    const/4 v9, 0x0

    goto/16 :goto_655

    .line 855
    :catch_1d
    move-exception v0

    const/4 v9, 0x0

    goto/16 :goto_62d

    .line 635
    :cond_21
    :try_start_21
    const-string v11, "{}"

    :goto_23
    invoke-direct {v10, v11}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 636
    new-instance v11, Lorg/json/JSONArray;

    iget-object v12, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->val$transactionsJson:Ljava/lang/String;
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_2a} :catch_62a
    .catchall {:try_start_21 .. :try_end_2a} :catchall_626

    if-eqz v12, :cond_2f

    :try_start_2c
    iget-object v12, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->val$transactionsJson:Ljava/lang/String;
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_2e} :catch_1d
    .catchall {:try_start_2c .. :try_end_2e} :catchall_19

    goto :goto_31

    :cond_2f
    :try_start_2f
    const-string v12, "[]"

    :goto_31
    invoke-direct {v11, v12}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 638
    const-string v12, "en"

    const-string v13, "lang"

    const-string v14, "hi"

    invoke-virtual {v10, v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v12

    .line 639
    const-string v13, "totalIn"

    const-wide/16 v14, 0x0

    invoke-virtual {v10, v13, v14, v15}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v16

    .line 640
    const-string v13, "totalOut"

    invoke-virtual {v10, v13, v14, v15}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v18

    .line 641
    const-string v13, "net"

    sub-long v14, v16, v18

    invoke-virtual {v10, v13, v14, v15}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v13

    .line 642
    const-string v15, "count"

    invoke-virtual {v11}, Lorg/json/JSONArray;->length()I

    move-result v9

    invoke-virtual {v10, v15, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v9

    .line 643
    invoke-virtual {v10, v2, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    .line 645
    new-instance v8, Landroid/graphics/pdf/PdfDocument;

    invoke-direct {v8}, Landroid/graphics/pdf/PdfDocument;-><init>()V
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_2f .. :try_end_6b} :catch_62a
    .catchall {:try_start_2f .. :try_end_6b} :catchall_626

    .line 646
    nop

    .line 647
    nop

    .line 648
    nop

    .line 650
    move-object/from16 v23, v3

    :try_start_70
    new-instance v3, Landroid/graphics/pdf/PdfDocument$PageInfo$Builder;

    move-object/from16 v24, v4

    const/16 v4, 0x253

    move-wide/from16 v25, v13

    const/16 v13, 0x34a

    const/4 v14, 0x1

    invoke-direct {v3, v4, v13, v14}, Landroid/graphics/pdf/PdfDocument$PageInfo$Builder;-><init>(III)V

    invoke-virtual {v3}, Landroid/graphics/pdf/PdfDocument$PageInfo$Builder;->create()Landroid/graphics/pdf/PdfDocument$PageInfo;

    move-result-object v3

    .line 651
    invoke-virtual {v8, v3}, Landroid/graphics/pdf/PdfDocument;->startPage(Landroid/graphics/pdf/PdfDocument$PageInfo;)Landroid/graphics/pdf/PdfDocument$Page;

    move-result-object v3

    .line 652
    invoke-virtual {v3}, Landroid/graphics/pdf/PdfDocument$Page;->getCanvas()Landroid/graphics/Canvas;

    move-result-object v14

    .line 654
    new-instance v4, Landroid/graphics/Paint;

    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    .line 655
    const/4 v13, 0x1

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 658
    const-string v13, "#1e3a8a"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 659
    new-instance v13, Landroid/graphics/RectF;

    move-object/from16 v27, v3

    const/high16 v3, 0x42d20000    # 105.0f

    move-object/from16 v33, v2

    const v2, 0x440bc000    # 559.0f

    move-object/from16 v34, v7

    const/high16 v7, 0x42100000    # 36.0f

    invoke-direct {v13, v7, v7, v2, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v3, 0x41000000    # 8.0f

    invoke-virtual {v14, v13, v3, v3, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 661
    const/4 v3, -0x1

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 662
    const/high16 v3, 0x41800000    # 16.0f

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 663
    sget-object v3, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v3, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 664
    if-eqz v12, :cond_cb

    const-string v3, "Yuva Shakti Group (Bhati Parivar Kuchera)"

    goto :goto_cd

    :cond_cb
    const-string v3, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a (\u092d\u093e\u091f\u0940 \u092a\u0930\u093f\u0935\u093e\u0930 \u0915\u0941\u091a\u0947\u0930\u093e)"

    .line 665
    :goto_cd
    const-string v13, "title"

    invoke-virtual {v10, v13, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 666
    const/high16 v13, 0x42800000    # 64.0f

    const/high16 v2, 0x42480000    # 50.0f

    invoke-virtual {v14, v3, v2, v13, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 668
    const-string v3, "#fbbf24"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 669
    const/high16 v3, 0x41300000    # 11.0f

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 670
    sget-object v3, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v3, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 671
    if-eqz v12, :cond_f7

    const-string v3, "Official Ledger & Financial Statement"

    goto :goto_f9

    :cond_f7
    const-string v3, "\u0906\u0927\u093f\u0915\u093e\u0930\u093f\u0915 \u092c\u0939\u0940-\u0916\u093e\u0924\u093e \u090f\u0935\u0902 \u0906\u092f-\u0935\u094d\u092f\u092f \u0930\u093f\u092a\u094b\u0930\u094d\u091f"

    .line 672
    :goto_f9
    const-string v13, "subTitle"

    invoke-virtual {v10, v13, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 673
    const/high16 v13, 0x42a40000    # 82.0f

    invoke-virtual {v14, v3, v2, v13, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 675
    const-string v3, "#e0e7ff"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 676
    const/high16 v3, 0x41100000    # 9.0f

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 677
    sget-object v13, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v3, 0x0

    invoke-static {v13, v3}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v13

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 678
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz v12, :cond_126

    const-string v29, "Report Date: "

    goto :goto_128

    :cond_126
    const-string v29, "\u0930\u093f\u092a\u094b\u0930\u094d\u091f \u0926\u093f\u0928\u093e\u0902\u0915: "

    :goto_128
    move-object/from16 v3, v29

    invoke-virtual {v13, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v13, "  |  "

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    if-eqz v12, :cond_13d

    const-string v13, "Total Records: "

    goto :goto_13f

    :cond_13d
    const-string v13, "\u0915\u0941\u0932 \u0932\u0947\u0928\u0926\u0947\u0928: "

    :goto_13f
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 679
    const/high16 v9, 0x42c00000    # 96.0f

    invoke-virtual {v14, v3, v2, v9, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 682
    nop

    .line 683
    nop

    .line 684
    nop

    .line 687
    const-string v2, "#ecfdf5"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 688
    new-instance v2, Landroid/graphics/RectF;

    const/high16 v3, 0x42e60000    # 115.0f

    const/high16 v9, 0x43200000    # 160.0f

    const/high16 v13, 0x434a0000    # 202.0f

    invoke-direct {v2, v7, v3, v13, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v15, 0x40c00000    # 6.0f

    invoke-virtual {v14, v2, v15, v15, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 689
    const-string v2, "#a7f3d0"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 690
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 691
    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2, v7, v3, v13, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v14, v2, v15, v15, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 692
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 693
    const-string v2, "#065f46"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 694
    const/high16 v2, 0x41100000    # 9.0f

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 695
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v7, 0x0

    invoke-static {v2, v7}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 696
    if-eqz v12, :cond_1a4

    const-string v2, "TOTAL DEPOSITS"

    goto :goto_1a6

    :cond_1a4
    const-string v2, "\u0915\u0941\u0932 \u091c\u092e\u093e (\u0905\u0902\u0936\u0926\u093e\u0928)"

    :goto_1a6
    const/high16 v7, 0x42380000    # 46.0f

    const/high16 v13, 0x43050000    # 133.0f

    invoke-virtual {v14, v2, v7, v13, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 697
    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 698
    const/high16 v2, 0x41600000    # 14.0f

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 699
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v2, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 700
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v13, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    const/4 v15, 0x1

    new-array v3, v15, [Ljava/lang/Object;

    const/16 v35, 0x0

    aput-object v16, v3, v35

    invoke-static {v13, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v3, 0x43170000    # 151.0f

    invoke-virtual {v14, v2, v7, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 703
    nop

    .line 704
    const-string v2, "#fef2f2"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 705
    new-instance v2, Landroid/graphics/RectF;

    const/high16 v7, 0x43560000    # 214.0f

    const/high16 v13, 0x43be0000    # 380.0f

    const/high16 v15, 0x42e60000    # 115.0f

    invoke-direct {v2, v7, v15, v13, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v15, 0x40c00000    # 6.0f

    invoke-virtual {v14, v2, v15, v15, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 706
    const-string v2, "#fecaca"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 707
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 708
    new-instance v2, Landroid/graphics/RectF;

    const/high16 v15, 0x42e60000    # 115.0f

    invoke-direct {v2, v7, v15, v13, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v15, 0x40c00000    # 6.0f

    invoke-virtual {v14, v2, v15, v15, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 709
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 710
    const-string v2, "#991b1b"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 711
    const/high16 v2, 0x41100000    # 9.0f

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 712
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v7, 0x0

    invoke-static {v2, v7}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 713
    if-eqz v12, :cond_240

    const-string v2, "TOTAL EXPENSES"

    goto :goto_242

    :cond_240
    const-string v2, "\u0915\u0941\u0932 \u0916\u0930\u094d\u091a (\u0935\u094d\u092f\u092f)"

    :goto_242
    const/high16 v7, 0x43600000    # 224.0f

    const/high16 v13, 0x43050000    # 133.0f

    invoke-virtual {v14, v2, v7, v13, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 714
    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 715
    const/high16 v2, 0x41600000    # 14.0f

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 716
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v2, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 717
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v13, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v15

    const/4 v9, 0x1

    new-array v3, v9, [Ljava/lang/Object;

    const/16 v35, 0x0

    aput-object v15, v3, v35

    invoke-static {v13, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v3, 0x43170000    # 151.0f

    invoke-virtual {v14, v2, v7, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 720
    nop

    .line 721
    const-string v2, "#eff6ff"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 722
    new-instance v2, Landroid/graphics/RectF;

    const/high16 v3, 0x43c40000    # 392.0f

    const v7, 0x440bc000    # 559.0f

    const/high16 v9, 0x43200000    # 160.0f

    const/high16 v15, 0x42e60000    # 115.0f

    invoke-direct {v2, v3, v15, v7, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v15, 0x40c00000    # 6.0f

    invoke-virtual {v14, v2, v15, v15, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 723
    const-string v2, "#bfdbfe"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 724
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 725
    new-instance v2, Landroid/graphics/RectF;

    const v7, 0x440bc000    # 559.0f

    const/high16 v9, 0x43200000    # 160.0f

    const/high16 v15, 0x42e60000    # 115.0f

    invoke-direct {v2, v3, v15, v7, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v15, 0x40c00000    # 6.0f

    invoke-virtual {v14, v2, v15, v15, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 726
    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 727
    const-string v2, "#1e40af"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 728
    const/high16 v2, 0x41100000    # 9.0f

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 729
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v7, 0x0

    invoke-static {v2, v7}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 730
    if-eqz v12, :cond_2e4

    const-string v2, "NET BALANCE"

    goto :goto_2e6

    :cond_2e4
    const-string v2, "\u0909\u092a\u0932\u092c\u094d\u0927 \u0936\u0947\u0937 \u0930\u093e\u0936\u093f"

    :goto_2e6
    const/high16 v3, 0x43c90000    # 402.0f

    const/high16 v13, 0x43050000    # 133.0f

    invoke-virtual {v14, v2, v3, v13, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 731
    const-string v2, "#1d4ed8"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 732
    const/high16 v2, 0x41600000    # 14.0f

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 733
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v2, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 734
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static/range {v25 .. v26}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    const/4 v13, 0x1

    new-array v15, v13, [Ljava/lang/Object;

    const/16 v35, 0x0

    aput-object v9, v15, v35

    invoke-static {v7, v5, v15}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v7, 0x43170000    # 151.0f

    invoke-virtual {v14, v2, v3, v7, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 737
    nop

    .line 738
    iget-object v2, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const/16 v3, 0xaf

    invoke-static {v2, v14, v4, v3, v12}, Lcom/yuvashaktigroup/app/MainActivity;->access$500(Lcom/yuvashaktigroup/app/MainActivity;Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V

    .line 739
    nop

    .line 742
    const/16 v2, 0xc7

    move-object/from16 v3, v27

    const/4 v7, 0x1

    const/4 v9, 0x0

    :goto_33b
    invoke-virtual {v11}, Lorg/json/JSONArray;->length()I

    move-result v13

    if-ge v9, v13, :cond_4f7

    .line 743
    const/16 v13, 0x316

    if-le v2, v13, :cond_374

    .line 744
    iget-object v2, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v2, v14, v4, v7, v12}, Lcom/yuvashaktigroup/app/MainActivity;->access$600(Lcom/yuvashaktigroup/app/MainActivity;Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V

    .line 745
    invoke-virtual {v8, v3}, Landroid/graphics/pdf/PdfDocument;->finishPage(Landroid/graphics/pdf/PdfDocument$Page;)V

    .line 747
    add-int/lit8 v7, v7, 0x1

    .line 748
    new-instance v2, Landroid/graphics/pdf/PdfDocument$PageInfo$Builder;

    const/16 v13, 0x253

    const/16 v15, 0x34a

    invoke-direct {v2, v13, v15, v7}, Landroid/graphics/pdf/PdfDocument$PageInfo$Builder;-><init>(III)V

    invoke-virtual {v2}, Landroid/graphics/pdf/PdfDocument$PageInfo$Builder;->create()Landroid/graphics/pdf/PdfDocument$PageInfo;

    move-result-object v2

    .line 749
    invoke-virtual {v8, v2}, Landroid/graphics/pdf/PdfDocument;->startPage(Landroid/graphics/pdf/PdfDocument$PageInfo;)Landroid/graphics/pdf/PdfDocument$Page;

    move-result-object v2

    .line 750
    invoke-virtual {v2}, Landroid/graphics/pdf/PdfDocument$Page;->getCanvas()Landroid/graphics/Canvas;

    move-result-object v14

    .line 752
    nop

    .line 753
    iget-object v3, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const/16 v13, 0x2d

    invoke-static {v3, v14, v4, v13, v12}, Lcom/yuvashaktigroup/app/MainActivity;->access$500(Lcom/yuvashaktigroup/app/MainActivity;Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V

    .line 754
    const/16 v3, 0x45

    move-object v3, v2

    const/16 v2, 0x45

    move-object/from16 v27, v14

    goto :goto_378

    .line 743
    :cond_374
    const/16 v15, 0x34a

    move-object/from16 v27, v14

    .line 757
    :goto_378
    invoke-virtual {v11, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    .line 758
    const-string v14, "description"

    move-object/from16 v15, v34

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    .line 759
    move-object/from16 v16, v3

    move/from16 v17, v7

    move-object/from16 v3, v33

    invoke-virtual {v13, v3, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 760
    move-object/from16 v33, v3

    const-string v3, "payMethod"

    invoke-virtual {v13, v3, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 761
    move/from16 v18, v9

    const-string v9, "type"

    invoke-virtual {v13, v9, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 762
    move-object/from16 v19, v11

    const-string v11, "amount"

    move-object/from16 v25, v5

    move-object/from16 v26, v6

    const-wide/16 v5, 0x0

    invoke-virtual {v13, v11, v5, v6}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v20

    .line 763
    const-string v11, "contribution"

    invoke-virtual {v11, v9}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v9

    .line 765
    rem-int/lit8 v11, v18, 0x2

    const/4 v13, 0x1

    if-ne v11, v13, :cond_3d4

    .line 766
    const-string v11, "#f8fafc"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 767
    add-int/lit8 v11, v2, -0xe

    int-to-float v11, v11

    add-int/lit8 v13, v2, 0x6

    int-to-float v13, v13

    const/high16 v28, 0x42100000    # 36.0f

    const v30, 0x440bc000    # 559.0f

    move-object/from16 v32, v4

    move/from16 v29, v11

    move/from16 v31, v13

    invoke-virtual/range {v27 .. v32}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 770
    :cond_3d4
    const-string v11, "#e2e8f0"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 771
    const/high16 v11, 0x3f000000    # 0.5f

    invoke-virtual {v4, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 772
    add-int/lit8 v11, v2, 0x6

    int-to-float v11, v11

    const v30, 0x440bc000    # 559.0f

    const/high16 v28, 0x42100000    # 36.0f

    move/from16 v31, v11

    move-object/from16 v32, v4

    move/from16 v29, v11

    invoke-virtual/range {v27 .. v32}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move-object/from16 v4, v27

    move-object/from16 v11, v32

    .line 774
    const-string v13, "#1e293b"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v11, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 775
    const/high16 v13, 0x41100000    # 9.0f

    invoke-virtual {v11, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 776
    sget-object v5, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v6, 0x1

    invoke-static {v5, v6}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v5

    invoke-virtual {v11, v5}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 777
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v6, 0x20

    if-le v5, v6, :cond_431

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x1e

    const/4 v13, 0x0

    invoke-virtual {v14, v13, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "..."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    .line 778
    :cond_431
    int-to-float v5, v2

    const/high16 v6, 0x42280000    # 42.0f

    invoke-virtual {v4, v14, v6, v5, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 780
    sget-object v6, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x0

    invoke-static {v6, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v6

    invoke-virtual {v11, v6}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 781
    const-string v6, "#475569"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v11, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 782
    const/high16 v6, 0x43750000    # 245.0f

    invoke-virtual {v4, v7, v6, v5, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 784
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v6

    const/16 v7, 0xe

    if-le v6, v7, :cond_471

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v7, 0xc

    const/4 v13, 0x0

    invoke-virtual {v3, v13, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, "..."

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 785
    :cond_471
    const v6, 0x43a28000    # 325.0f

    invoke-virtual {v4, v3, v6, v5, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 787
    if-eqz v9, :cond_481

    if-eqz v12, :cond_47e

    const-string v3, "Deposit"

    goto :goto_488

    :cond_47e
    const-string v3, "\u091c\u092e\u093e"

    goto :goto_488

    :cond_481
    if-eqz v12, :cond_486

    const-string v3, "Expense"

    goto :goto_488

    :cond_486
    const-string v3, "\u0916\u0930\u094d\u091a"

    .line 788
    :goto_488
    if-eqz v9, :cond_48f

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    goto :goto_493

    :cond_48f
    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    :goto_493
    invoke-virtual {v11, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 789
    sget-object v6, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-static {v6, v13}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v6

    invoke-virtual {v11, v6}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 790
    const/high16 v6, 0x43cd0000    # 410.0f

    invoke-virtual {v4, v3, v6, v5, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 792
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v6, v26

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v13

    move/from16 v20, v2

    const/4 v14, 0x1

    new-array v2, v14, [Ljava/lang/Object;

    const/16 v35, 0x0

    aput-object v13, v2, v35

    move-object/from16 v13, v25

    invoke-static {v7, v13, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 793
    if-eqz v9, :cond_4d4

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    goto :goto_4d8

    :cond_4d4
    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    :goto_4d8
    invoke-virtual {v11, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 794
    invoke-virtual {v11, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v3

    .line 795
    const v7, 0x44098000    # 550.0f

    sub-float/2addr v7, v3

    invoke-virtual {v4, v2, v7, v5, v11}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 797
    add-int/lit8 v2, v20, 0x14

    .line 742
    add-int/lit8 v9, v18, 0x1

    move-object v14, v4

    move-object v4, v11

    move-object v5, v13

    move-object/from16 v34, v15

    move-object/from16 v3, v16

    move/from16 v7, v17

    move-object/from16 v11, v19

    goto/16 :goto_33b

    .line 800
    :cond_4f7
    move-object v11, v4

    move-object/from16 v15, v34

    iget-object v2, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v2, v14, v11, v7, v12}, Lcom/yuvashaktigroup/app/MainActivity;->access$600(Lcom/yuvashaktigroup/app/MainActivity;Landroid/graphics/Canvas;Landroid/graphics/Paint;IZ)V

    .line 801
    invoke-virtual {v8, v3}, Landroid/graphics/pdf/PdfDocument;->finishPage(Landroid/graphics/pdf/PdfDocument$Page;)V

    .line 804
    sget-object v2, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-static {v2}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    .line 805
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_511

    .line 806
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 808
    :cond_511
    new-instance v3, Ljava/text/SimpleDateFormat;

    const-string v4, "yyyyMMdd_HHmmss"

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v3, v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v4, Ljava/util/Date;

    invoke-direct {v4}, Ljava/util/Date;-><init>()V

    invoke-virtual {v3, v4}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    .line 809
    const-string v4, "filePrefix"

    const-string v5, "Yuva_Shakti_BahiKhata_"

    invoke-virtual {v10, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 810
    new-instance v5, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v5, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 812
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_54a
    .catch Ljava/lang/Exception; {:try_start_70 .. :try_end_54a} :catch_623
    .catchall {:try_start_70 .. :try_end_54a} :catchall_620

    .line 813
    :try_start_54a
    invoke-virtual {v8, v3}, Landroid/graphics/pdf/PdfDocument;->writeTo(Ljava/io/OutputStream;)V
    :try_end_54d
    .catchall {:try_start_54a .. :try_end_54d} :catchall_615

    .line 814
    :try_start_54d
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    .line 816
    new-instance v3, Ljava/io/File;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "_$"

    invoke-virtual {v4, v7, v15}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v2, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 817
    iget-object v0, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v0, v5, v3}, Lcom/yuvashaktigroup/app/MainActivity;->access$300(Lcom/yuvashaktigroup/app/MainActivity;Ljava/io/File;Ljava/io/File;)V

    .line 820
    iget-object v0, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    .line 822
    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x2

    new-array v6, v4, [Ljava/lang/String;

    const/16 v35, 0x0

    aput-object v2, v6, v35

    const/16 v22, 0x1

    aput-object v3, v6, v22

    new-array v2, v4, [Ljava/lang/String;

    const-string v3, "application/pdf"

    const/16 v35, 0x0

    aput-object v3, v2, v35

    const/16 v22, 0x1

    aput-object v3, v2, v22

    .line 820
    const/4 v3, 0x0

    invoke-static {v0, v6, v2, v3}, Landroid/media/MediaScannerConnection;->scanFile(Landroid/content/Context;[Ljava/lang/String;[Ljava/lang/String;Landroid/media/MediaScannerConnection$OnScanCompletedListener;)V

    .line 827
    iget-object v0, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v2, "download"

    invoke-virtual {v0, v2}, Lcom/yuvashaktigroup/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Landroid/app/DownloadManager;

    .line 828
    if-eqz v13, :cond_5bb

    .line 829
    nop

    .line 830
    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v14

    const-string v15, "\u092f\u0941\u0935\u093e \u0936\u0915\u094d\u0924\u093f \u0917\u094d\u0930\u0941\u092a \u092c\u0939\u0940-\u0916\u093e\u0924\u093e \u0930\u093f\u092a\u094b\u0930\u094d\u091f"

    const-string v17, "application/pdf"

    .line 834
    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v18

    .line 835
    invoke-virtual {v5}, Ljava/io/File;->length()J

    move-result-wide v19

    .line 829
    const/16 v16, 0x1

    const/16 v21, 0x1

    invoke-virtual/range {v13 .. v21}, Landroid/app/DownloadManager;->addCompletedDownload(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;JZ)J

    .line 840
    :cond_5bb
    iget-object v0, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\ud83d\udcc4 \u092c\u0939\u0940-\u0916\u093e\u0924\u093e PDF \u0921\u093e\u0909\u0928\u0932\u094b\u0921 \u092b\u094b\u0932\u094d\u0921\u0930 \u092e\u0947\u0902 \u0938\u0947\u0935 \u0939\u094b \u0917\u0908:\n"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x1

    invoke-static {v0, v2, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_5dc
    .catch Ljava/lang/Exception; {:try_start_54d .. :try_end_5dc} :catch_623
    .catchall {:try_start_54d .. :try_end_5dc} :catchall_620

    .line 844
    :try_start_5dc
    new-instance v0, Landroid/os/StrictMode$VmPolicy$Builder;

    invoke-direct {v0}, Landroid/os/StrictMode$VmPolicy$Builder;-><init>()V

    .line 845
    invoke-virtual {v0}, Landroid/os/StrictMode$VmPolicy$Builder;->build()Landroid/os/StrictMode$VmPolicy;

    move-result-object v0

    invoke-static {v0}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    .line 847
    new-instance v0, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 848
    invoke-static {v5}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "application/pdf"

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    .line 849
    const v2, 0x10000001

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 850
    iget-object v2, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    if-eqz v12, :cond_605

    const-string v3, "Open PDF Report"

    goto :goto_607

    :cond_605
    const-string v3, "\u092c\u0939\u0940-\u0916\u093e\u0924\u093e PDF \u0916\u094b\u0932\u0947\u0902"

    :goto_607
    invoke-static {v0, v3}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_60e
    .catch Ljava/lang/Exception; {:try_start_5dc .. :try_end_60e} :catch_60f
    .catchall {:try_start_5dc .. :try_end_60e} :catchall_620

    .line 853
    goto :goto_610

    .line 851
    :catch_60f
    move-exception v0

    .line 858
    :goto_610
    nop

    .line 859
    invoke-virtual {v8}, Landroid/graphics/pdf/PdfDocument;->close()V

    goto :goto_653

    .line 812
    :catchall_615
    move-exception v0

    move-object v2, v0

    :try_start_617
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_61a
    .catchall {:try_start_617 .. :try_end_61a} :catchall_61b

    goto :goto_61f

    :catchall_61b
    move-exception v0

    :try_start_61c
    invoke-static {v2, v0}, Lcom/yuvashaktigroup/app/MainActivity$0;->m(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :goto_61f
    throw v2
    :try_end_620
    .catch Ljava/lang/Exception; {:try_start_61c .. :try_end_620} :catch_623
    .catchall {:try_start_61c .. :try_end_620} :catchall_620

    .line 858
    :catchall_620
    move-exception v0

    move-object v9, v8

    goto :goto_655

    .line 855
    :catch_623
    move-exception v0

    move-object v9, v8

    goto :goto_62d

    .line 858
    :catchall_626
    move-exception v0

    const/4 v3, 0x0

    move-object v9, v3

    goto :goto_655

    .line 855
    :catch_62a
    move-exception v0

    const/4 v3, 0x0

    move-object v9, v3

    .line 856
    :goto_62d
    :try_start_62d
    iget-object v2, v1, Lcom/yuvashaktigroup/app/MainActivity$9;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "PDF \u0924\u0948\u092f\u093e\u0930 \u0915\u0930\u0928\u0947 \u092e\u0947\u0902 \u0924\u094d\u0930\u0941\u091f\u093f: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x1

    invoke-static {v2, v0, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_64e
    .catchall {:try_start_62d .. :try_end_64e} :catchall_654

    .line 858
    if-eqz v9, :cond_653

    .line 859
    invoke-virtual {v9}, Landroid/graphics/pdf/PdfDocument;->close()V

    .line 862
    :cond_653
    :goto_653
    return-void

    .line 858
    :catchall_654
    move-exception v0

    :goto_655
    if-eqz v9, :cond_65a

    .line 859
    invoke-virtual {v9}, Landroid/graphics/pdf/PdfDocument;->close()V

    .line 861
    :cond_65a
    goto :goto_65c

    :goto_65b
    throw v0

    :goto_65c
    goto :goto_65b
.end method

###### Class com.yuvashaktigroup.app.MainActivity.WebAppInterface (com.yuvashaktigroup.app.MainActivity$WebAppInterface)
.class public Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;
.super Ljava/lang/Object;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/yuvashaktigroup/app/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "WebAppInterface"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/yuvashaktigroup/app/MainActivity;


# direct methods
.method public constructor <init>(Lcom/yuvashaktigroup/app/MainActivity;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 55
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public downloadAndInstall(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 58
    iget-object p2, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p2, p1}, Lcom/yuvashaktigroup/app/MainActivity;->downloadAndInstallApk(Ljava/lang/String;)V

    .line 59
    return-void
.end method

.method public hasNotificationPermission()Z
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 120
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    const/4 v2, 0x1

    if-lt v0, v1, :cond_14

    .line 121
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v1, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {v0, v1}, Lcom/yuvashaktigroup/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_12

    goto :goto_13

    :cond_12
    const/4 v2, 0x0

    :goto_13
    return v2

    .line 123
    :cond_14
    return v2
.end method

.method public openWhatsApp(Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 84
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v0, v1, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 85
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {p1, v0}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_10} :catch_11

    .line 88
    goto :goto_1e

    .line 86
    :catch_11
    move-exception p1

    .line 87
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string v0, "\u0935\u094d\u0939\u093e\u091f\u094d\u0938\u090f\u092a \u0909\u092a\u0932\u092c\u094d\u0927 \u0928\u0939\u0940\u0902 \u0939\u0948"

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 89
    :goto_1e
    return-void
.end method

.method public postNotification(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 105
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->access$000(Lcom/yuvashaktigroup/app/MainActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 106
    return-void
.end method

.method public printLedgerPdf()V
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 73
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v0}, Lcom/yuvashaktigroup/app/MainActivity;->printLedgerReport()V

    .line 74
    return-void
.end method

.method public requestNotificationPermission()V
    .registers 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 110
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    new-instance v1, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface$1;

    invoke-direct {v1, p0}, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface$1;-><init>(Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;)V

    invoke-virtual {v0, v1}, Lcom/yuvashaktigroup/app/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 116
    return-void
.end method

.method public saveLedgerPdf(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 78
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->generateAndSaveLedgerPdf(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    return-void
.end method

.method public shareAppApk()V
    .registers 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 63
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v0}, Lcom/yuvashaktigroup/app/MainActivity;->shareApplicationApk()V

    .line 64
    return-void
.end method

.method public shareImage(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 68
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-virtual {v0, p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->shareGeneratedImage(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    return-void
.end method

.method public shareText(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 94
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.SEND"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 95
    const-string v1, "text/plain"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 96
    const-string v1, "android.intent.extra.TEXT"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 97
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    if-eqz p2, :cond_16

    goto :goto_18

    :cond_16
    const-string p2, "\u0936\u0947\u092f\u0930 \u0915\u0930\u0947\u0902"

    :goto_18
    invoke-static {v0, p2}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/yuvashaktigroup/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_1f} :catch_20

    .line 100
    goto :goto_2d

    .line 98
    :catch_20
    move-exception p1

    .line 99
    iget-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    const-string p2, "\u0936\u0947\u092f\u0930 \u0915\u0930\u0928\u0947 \u092e\u0947\u0902 \u0924\u094d\u0930\u0941\u091f\u093f"

    const/4 v0, 0x0

    invoke-static {p1, p2, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 101
    :goto_2d
    return-void
.end method

###### Class com.yuvashaktigroup.app.MainActivity.WebAppInterface.AnonymousClass1 (com.yuvashaktigroup.app.MainActivity$WebAppInterface$1)
.class Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface$1;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->requestNotificationPermission()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;


# direct methods
.method constructor <init>(Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 110
    iput-object p1, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    .line 113
    iget-object v0, p0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface$1;->this$1:Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;

    iget-object v0, v0, Lcom/yuvashaktigroup/app/MainActivity$WebAppInterface;->this$0:Lcom/yuvashaktigroup/app/MainActivity;

    invoke-static {v0}, Lcom/yuvashaktigroup/app/MainActivity;->access$100(Lcom/yuvashaktigroup/app/MainActivity;)V

    .line 114
    return-void
.end method
