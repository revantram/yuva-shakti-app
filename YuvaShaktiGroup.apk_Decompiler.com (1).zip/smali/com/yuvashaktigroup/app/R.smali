###### Class com.yuvashaktigroup.app.R (com.yuvashaktigroup.app.R)
.class public final Lcom/yuvashaktigroup/app/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/yuvashaktigroup/app/R$string;,
        Lcom/yuvashaktigroup/app/R$mipmap;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.yuvashaktigroup.app.R.mipmap (com.yuvashaktigroup.app.R$mipmap)
.class public final Lcom/yuvashaktigroup/app/R$mipmap;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/yuvashaktigroup/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mipmap"
.end annotation


# static fields
.field public static final ic_launcher:I = 0x7f010000

.field public static final ic_launcher_round:I = 0x7f010001


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.yuvashaktigroup.app.R.string (com.yuvashaktigroup.app.R$string)
.class public final Lcom/yuvashaktigroup/app/R$string;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/yuvashaktigroup/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final app_name:I = 0x7f020000


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
