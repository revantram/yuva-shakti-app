###### Class com.yuvashaktigroup.app.AppFileProvider (com.yuvashaktigroup.app.AppFileProvider)
.class public Lcom/yuvashaktigroup/app/AppFileProvider;
.super Landroid/content/ContentProvider;
.source "AppFileProvider.java"


# static fields
.field public static final AUTHORITY:Ljava/lang/String; = "com.yuvashaktigroup.app.fileprovider"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 18
    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    return-void
.end method

.method private getFileForUri(Landroid/net/Uri;)Ljava/io/File;
    .registers 5

    .line 72
    invoke-virtual {p0}, Lcom/yuvashaktigroup/app/AppFileProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    .line 73
    :cond_8
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p1

    .line 74
    if-nez p1, :cond_f

    return-object v1

    .line 75
    :cond_f
    const-string v0, "/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1c

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    .line 78
    :cond_1c
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lcom/yuvashaktigroup/app/AppFileProvider;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v2

    invoke-direct {v0, v2, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 79
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_30

    return-object v0

    .line 83
    :cond_30
    :try_start_30
    invoke-virtual {p0}, Lcom/yuvashaktigroup/app/AppFileProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getExternalCacheDir()Ljava/io/File;

    move-result-object v0

    .line 84
    if-eqz v0, :cond_47

    .line 85
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 86
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v0
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_30 .. :try_end_43} :catch_46

    if-eqz v0, :cond_47

    return-object v2

    .line 88
    :catch_46
    move-exception v0

    :cond_47
    nop

    .line 91
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lcom/yuvashaktigroup/app/AppFileProvider;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-direct {v0, v2, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 92
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_5c

    return-object v0

    .line 96
    :cond_5c
    :try_start_5c
    invoke-virtual {p0}, Lcom/yuvashaktigroup/app/AppFileProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .line 97
    if-eqz v0, :cond_73

    .line 98
    new-instance v2, Ljava/io/File;

    invoke-direct {v2, v0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 99
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p1
    :try_end_6f
    .catch Ljava/lang/Exception; {:try_start_5c .. :try_end_6f} :catch_72

    if-eqz p1, :cond_73

    return-object v2

    .line 101
    :catch_72
    move-exception p1

    :cond_73
    nop

    .line 103
    return-object v1
.end method


# virtual methods
.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 4

    .line 110
    const/4 p1, 0x0

    return p1
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 3

    .line 49
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p1

    .line 50
    if-eqz p1, :cond_11

    const-string v0, ".apk"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 51
    const-string p1, "application/vnd.android.package-archive"

    return-object p1

    .line 52
    :cond_11
    if-eqz p1, :cond_26

    const-string v0, ".jpg"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_23

    const-string v0, ".jpeg"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_26

    .line 53
    :cond_23
    const-string p1, "image/jpeg"

    return-object p1

    .line 54
    :cond_26
    if-eqz p1, :cond_33

    const-string v0, ".png"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_33

    .line 55
    const-string p1, "image/png"

    return-object p1

    .line 56
    :cond_33
    if-eqz p1, :cond_40

    const-string v0, ".pdf"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_40

    .line 57
    const-string p1, "application/pdf"

    return-object p1

    .line 59
    :cond_40
    const-string p1, "application/octet-stream"

    return-object p1
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 3

    .line 107
    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()Z
    .registers 2

    .line 23
    const/4 v0, 0x1

    return v0
.end method

.method public openFile(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    .line 64
    invoke-direct {p0, p1}, Lcom/yuvashaktigroup/app/AppFileProvider;->getFileForUri(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p2

    .line 65
    if-eqz p2, :cond_13

    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_13

    .line 66
    const/high16 p1, 0x10000000

    invoke-static {p2, p1}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    return-object p1

    .line 68
    :cond_13
    new-instance p2, Ljava/io/FileNotFoundException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "File not found for URI: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw p2
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 10

    .line 28
    const-string p3, "_size"

    const-string p4, "_display_name"

    const/4 p5, 0x0

    if-nez p2, :cond_f

    .line 29
    const/4 p2, 0x2

    new-array p2, p2, [Ljava/lang/String;

    aput-object p4, p2, p5

    const/4 v0, 0x1

    aput-object p3, p2, v0

    .line 31
    :cond_f
    new-instance v0, Landroid/database/MatrixCursor;

    invoke-direct {v0, p2}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;)V

    .line 32
    invoke-direct {p0, p1}, Lcom/yuvashaktigroup/app/AppFileProvider;->getFileForUri(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p1

    .line 33
    if-eqz p1, :cond_4e

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_4e

    .line 34
    array-length v1, p2

    new-array v1, v1, [Ljava/lang/Object;

    .line 35
    nop

    :goto_24
    array-length v2, p2

    if-ge p5, v2, :cond_4b

    .line 36
    aget-object v2, p2, p5

    invoke-virtual {p4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_36

    .line 37
    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, p5

    goto :goto_48

    .line 38
    :cond_36
    aget-object v2, p2, p5

    invoke-virtual {p3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_48

    .line 39
    invoke-virtual {p1}, Ljava/io/File;->length()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    aput-object v2, v1, p5

    .line 35
    :cond_48
    :goto_48
    add-int/lit8 p5, p5, 0x1

    goto :goto_24

    .line 42
    :cond_4b
    invoke-virtual {v0, v1}, Landroid/database/MatrixCursor;->addRow([Ljava/lang/Object;)V

    .line 44
    :cond_4e
    return-object v0
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 5

    .line 113
    const/4 p1, 0x0

    return p1
.end method
